package com.springboot.EmployeeManagementSystem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.EmployeeManagementSystem.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Integer> {
	//Derived query methods
	
	Department findByName(String name);

}
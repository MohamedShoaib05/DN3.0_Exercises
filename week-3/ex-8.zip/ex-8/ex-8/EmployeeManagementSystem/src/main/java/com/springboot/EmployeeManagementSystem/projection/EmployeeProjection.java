package com.springboot.EmployeeManagementSystem.projection;
public interface EmployeeProjection {
	String getName();
	String getEmail();

}